# LYSHLbot

A powerful OneBot Protocol Robot Framework with WebSocket reverse proxy support.

## Features

- **OneBot v11 Protocol Support**: Compatible with napcat and other OneBot v11 implementations
- **WebSocket Reverse Proxy**: Built-in WebSocket server for reverse connections
- **Cross-Platform**: Supports Windows and Linux systems
- **Modern Web Interface**: Clean and professional dashboard
- **Plugin System**: Extensible architecture for custom functionality

## Requirements

- Node.js >= 18.0.0
- npm >= 9.0.0

## Installation

### Windows

```bash
scripts\windows\install.bat
```

### Linux

```bash
chmod +x scripts/linux/install.sh
bash scripts/linux/install.sh
```

## Quick Start

```bash
npm start
```

Visit http://localhost:3000 to access the dashboard.

## Project Structure

```
LYSHLbot/
├── backend/
│   └── node/              # Node.js implementation
│       └── src/
│           ├── index.js   # Main entry
│           ├── core/      # Core modules
│           ├── websocket/ # WebSocket manager
│           ├── protocols/ # Protocol adapters
│           ├── config/    # Configuration
│           └── utils/     # Utilities
├── frontend/
│   └── dist/             # Web interface
├── scripts/
│   ├── windows/          # Windows scripts
│   └── linux/            # Linux scripts
└── config/               # Configuration files
```

## Configuration

Edit `config/config.yaml` or copy `.env.example` to `.env`:

```yaml
app:
  host: "0.0.0.0"
  port: 3000

onebot:
  adapters:
    napcat:
      ws_url: "ws://127.0.0.1:3001"
```

## WebSocket Endpoints

- `/ws/reverse` - Main WebSocket reverse proxy endpoint
- `/api/status` - Server status API
- `/api/config` - Public configuration
- `/api/ws/connect` - Initiate connection to remote WebSocket

## License

MIT
